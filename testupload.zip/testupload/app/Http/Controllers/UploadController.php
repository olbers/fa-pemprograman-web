<?php namespace App\Http\Controllers;

use \Input as Input;

class UploadController extends Controller {
	
	public function upload(){
	
		if(Input::hasFile('file')){
		
			echo 'File Upload<br/>';
			$file = Input::file('file');
			$file->move('uploads',$file->getClientOriginalName());
			
			echo 'file name: '.$file->getClientOriginalName();
			echo '<br>';
			
			echo 'file extension: '.$file->getClientOriginalExtension();
			echo '<br>';
			
			echo 'file size: '.$file->getClientSize();
			echo '<br>';
			
			echo 'file path: '.$file->getRealPath();
			echo '<br>';
			
			echo '<img src="uploads/' . $file->getClientOriginalName() . '"/>';

		}
	}
}